/*
 * apigpio.h
 *
 *  Created on: 2015年11月2日
 *      Author: test
 */

#ifndef L2FRAME_APIGPIO_H_
#define L2FRAME_APIGPIO_H_

#include "../comvm/vmlayer.h"

/*
 * Function API prototype for Serial Port
 */
//UINT32 GpioInit();
//UINT32 GpioPortOp();
//void GpioPortOp(char *op)

#endif /* L2FRAME_APIGPIO_H_ */







