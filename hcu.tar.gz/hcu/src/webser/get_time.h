/*
 * get_time.h
 *
 *  Created on: 2015年12月1日
 *      Author: test
 */

#ifndef WEBSER_GET_TIME_H_
#define WEBSER_GET_TIME_H_

#define TIME_BUFFER_SIZE    40    /* buffer size of time_buffer */

char *get_time_str(char *time_buf);


#endif /* WEBSER_GET_TIME_H_ */
